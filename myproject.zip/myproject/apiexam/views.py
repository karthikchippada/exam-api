from django.shortcuts import render
from rest_framework.views import APIView
from anotherproject.connnectionfiles.create_data import post_create_data

# Create your views here.
class createproduct_data(APIView):
    def post(self, request, format=None):
        return post_create_data(request)