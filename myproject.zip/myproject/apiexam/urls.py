from django.contrib import admin
from django.urls import path,include
from django.views.decorators.csrf import csrf_exempt

from apiexam.views import createproduct_data

urlpatterns = [
    path('createproduct_data',csrf_exempt(createproduct_data.as_view())),
]