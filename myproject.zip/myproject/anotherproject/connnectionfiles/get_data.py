import os
from urllib import response


from rest_framework import status
from rest_framework.response import Response

from utils.check_data import ecomerce_presence

from utils.mongo_func import connect


class child_details:
    
    
    def get_data(self,db): #insertion function
        data=db.table2.find()
        temp=[]
        for datas in data:
            temp.append({datas['productname'], datas["productprice"]})
        return temp
    
   
def post_get_data(request):
    
    #used based on requirement
    # res, message = check_presence(request, ["productname"])

    # if not res:
    #     return Response({'status' : False, 'message' : message}, status = 400)
    # productname = request.data.get('productname')
    # print(res)
  
    try:
        client = connect()
       
    except:
       
        return Response({'status' : False, 'message' : 'Error in connecting with database'}, 502)

    db = client.ecomerce  # database name  

    new_child = child_details()
    get_details=new_child.get_data(db)
    return Response(get_details,status=200)
