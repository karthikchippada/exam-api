import os
from sre_constants import SUCCESS
# from unicodedata import productname
from urllib import response


from rest_framework import status
from rest_framework.response import Response
# from myproject.anotherproject.views import delete_data

from utils.check_data import ecomerce_presence

from utils.mongo_func import connect


class child_details:
    def __init__(self, productname,productprice):
        
        self.productname = productname
        self.productprice = productprice
    
    def delete_data(self,db): #insertion function
        #mylist = [
         #   {'productname':self.productname,'productprice':self.productprice}
        #]
        db.table2.delete_one({'productname':self.productname})
         
   
def get_delete_data(request):
    
    #used based on requirement
    res, message = ecomerce_presence(request, ["productname","productprice"])

    if not res:
        return Response({'status' : False, 'message' : message}, status = 400)
    productname = request.data.get('productname',)
    productprice= request.data.get('productprice',)
    
    print(res)
  
    try:
        client = connect()
       
    except:
       
        return Response({'status' : False, 'message' : 'Error in connecting with database'}, 502)

    db = client.ecomerce   # database name  

    new_child = child_details(productname,productprice)
    get_details=new_child.delete_data(db)
    return Response("product deleted!",status=200)
