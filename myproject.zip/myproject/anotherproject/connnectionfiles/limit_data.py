import os
from urllib import response


from rest_framework import status
from rest_framework.response import Response

from utils.check_data import ecomerce_presence

from utils.mongo_func import connect


class child_details:
    
    
    def limit_data(self,db): #insertion function
        data=db.table2.find().limit(2)
        temp=[]
        for datas in data:
            temp.append({"productname": datas["productname"]})
        return temp
    
   
def post_limit_data(request):
    
    #used based on requirement
    # res, message = check_presence(request, ["name"])

    # if not res:
    #     return Response({'status' : False, 'message' : message}, status = 400)
    # name = request.data.get('name')
    # print(res)
  
    try:
        client = connect()
       
    except:
       
        return Response({'status' : False, 'message' : 'Error in connecting with database'}, 502)

    db = client.ecomerce   # database name  

    new_child = child_details()
    get_details=new_child.limit_data(db)
    return Response(get_details,status=200)