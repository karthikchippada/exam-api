import os
from sre_constants import SUCCESS
# from unicodedata import productname
from urllib import response


from rest_framework import status
from rest_framework.response import Response
# from myproject.anotherproject.views import delete_data

from utils.check_data import ecomerce_presence

from utils.mongo_func import connect


class child_details:
    def __init__(self,productname,productname1):
        self.productname = productname
        self.productname1 = productname1
        
    def update_data(self,db):
        db.table2.update_many({'productname': self.productname},{"$set":{'productname':self.productname1}}) 
        
    # def find_data(self,db): #insertion function
    #     data=db.table1.find({},{"productname":self.productname1})
    #     temp=[]
    #     for datas in data:
    #         print(datas)
    #         temp.append({"productname": datas["productname"]})
    #     return temp
  
         
   
def get_update_data(request):
    
    #used based on requirement
    res, message = ecomerce_presence(request, ["productname","productname1"])

    if not res:
        return Response({'status' : False, 'message' : message}, status = 400)
    productname = request.data.get('productname')
    productname1 = request.data.get('productname1')
    print(res)
  
    try:
        client = connect()
       
    except:
       
        return Response({'status' : False, 'message' : 'Error in connecting with database'}, 502)

    db = client.ecomerce   # database name  

    new_child = child_details(productname,productname1)
    get_details=new_child.update_data(db)
    # get_details=new_child.find_data(db)
    return Response(get_details,status=200)
    return Response("product updated ",status=200)
