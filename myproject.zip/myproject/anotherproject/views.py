from django.shortcuts import render
from rest_framework.views import APIView
from anotherproject.connnectionfiles.create_data import post_create_data
from anotherproject.connnectionfiles.get_data import post_get_data
from anotherproject.connnectionfiles.delete_data import get_delete_data
from anotherproject.connnectionfiles.update_data import get_update_data
from anotherproject.connnectionfiles.sort_data import post_sort_data
from anotherproject.connnectionfiles.limit_data import post_limit_data
class limit_data(APIView):
    def get(self, request):
        return post_limit_data(request)   
# Create your views here.
class create_data(APIView):
    def post(self, request, format=None):
        return post_create_data(request)

class get_data(APIView):
    def get(self, request):
        return post_get_data(request)
    
class delete_data(APIView):
    def post(self,request,format=None):
        return get_delete_data(request)
class update_data(APIView):
    def post(self,request,format=None):
        return get_update_data(request)    
    
class limit_data(APIView):
    def get(self, request):
        return post_limit_data(request)    
    
class sort_data(APIView):
    def get(self, request):
        return post_sort_data(request)   
  
  
  
  
        
        