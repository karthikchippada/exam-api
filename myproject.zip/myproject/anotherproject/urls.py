from django.contrib import admin
from django.urls import path,include
from django.views.decorators.csrf import csrf_exempt

from anotherproject.views import create_data,get_data,delete_data,update_data,limit_data,sort_data

urlpatterns = [
    path('create_data',csrf_exempt(create_data.as_view())),
    path('get_data',csrf_exempt(get_data.as_view())),
    path('delete_data',csrf_exempt(delete_data.as_view())),
    path('update_data',csrf_exempt(update_data.as_view())),
    path('limit_data',csrf_exempt(limit_data.as_view())),
    path('sort_data',csrf_exempt(sort_data.as_view())),
]