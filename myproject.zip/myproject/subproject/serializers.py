from rest_framework import serializers
from subproject.models import rest

class Itemserializer(serializers.ModelSerializer):
    class Meta:
        model = rest
        fields = '__all__'