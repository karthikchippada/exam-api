from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from subproject.models import rest
from .serializers import Itemserializer

@api_view(['GET'])
def getData(request):
    items = rest.objects.all()
    serializer = Itemserializer(items,many=True)
    return Response(serializer.data)

@api_view(['POST'])
def addItem(request):
    serializer = Itemserializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
    print(serializer)
    return Response(serializer.data)